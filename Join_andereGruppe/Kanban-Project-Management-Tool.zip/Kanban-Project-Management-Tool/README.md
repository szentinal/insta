# JOIN Kanban Project Management Tool

	Join helps to manage your schedules and notes. 
	It gives you a quick and simple notepad editing 
	experience when you write notes, memo, email, 
	message, shopping list and to do list. 
	You have prioritizing and deadline options in your tasks.

	Dev-Team:
	Hasan Altay
	Christian Axtmann
	Malaica Brunks
	Joachim Dürr

